ki5 = 5
d3 = ki5
d2 = ki5


