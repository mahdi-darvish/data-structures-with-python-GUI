from django.shortcuts import render
from .src.test import test
from .src.chapter02 import (
    eratosthenes,
    char_replacement,
    repeated_ints,
    b_search,
    matrix,
    lcs,
    pi_e
)
import numpy as np
from .src.chapter3 import (
    reverse,
    binary,
    lis
)

from .src.chapter4 import (
    DoublyLinkedList,
    DoublyLinkedList2
)

from .src.chapter4 import (
    selection_sort,
    bubble_sort,
    insertion_sort,
    quick_sort,
    merge_sort,
    quick,
    mergeSortInversions,
)

from .src.chapter6 import (
    dfs,
    dfs_print,
    BSTree,
    dfs_iterative,
    bfs,
    dfs2,
    dff,
    Graph,
    hff,
)



def homepage(request):
    return render(request, 'main/index2.html')


def chapter1(request):
    return render(request, 'main/chapter1.html')


def chapter2(request):
    return render(request, 'main/chapter2.html')


def chapter3(request):
    return render(request, 'main/chapter3.html')


def chapter4(request):
    return render(request, 'main/chapter4.html')

def chapter5(request):
    return render(request, 'main/chapter5.html')

def chapter6(request):
    return render(request, 'main/chapter6.html')

def chapter7(request):
    return render(request, 'main/chapter7.html')

def chapter8(request):
    return render(request, 'main/chapter8.html')



def chapter1q(request):
    return render(request, 'main/question01.html')


def chapter2q1(request):
    ans = ''
    if request.method == 'POST':
        numb = request.POST.get('numb')
        ans = eratosthenes(int(numb))
    return render(request, 'main/chapter2/question01.html', {'ans': ans})


def chapter2q2(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        print(st)
        ans = char_replacement(st)
    return render(request, 'main/chapter2/question02.html', {'ans': ans})



def chapter2q3(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        ans = repeated_ints(st)
    return render(request, 'main/chapter2/question03.html', {'ans': ans})


def chapter2q4(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        st2 = request.POST.get('st2')
        ans = b_search(st, int(st2))
    return render(request, 'main/chapter2/question04.html', {'ans': ans})


def chapter2q5(request):
    ans = ''
    x = ''
    y = ''
    ans2 = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        st2 = request.POST.get('st2')
        ans = matrix(st, st2)
        x = len(ans)
        y = len(ans[0])
        if type(ans) == str:
            ans2 = ans
            ans = ''
    return render(request, 'main/chapter2/question05.html', {'ans': ans,'x': x,'y': y, 'ans2': ans2})


def chapter2q7(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        ans = lcs((st))
    return render(request, 'main/chapter2/question07.html', {'ans': ans})


def chapter2q6(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        ans = pi_e(int(st))
        ans[1] = round(ans[1], 4)
        ans[0] = round(ans[0], 4)
    return render(request, 'main/chapter2/question06.html', {'ans': ans})


def chapter3q1(request):
    ans = ''
    if request.method == 'POST':
        numb = request.POST.get('numb')
        ans = eratosthenes(int(numb))
    return render(request, 'main/chapter3/question01.html', {'ans': ans})


def chapter3q2(request):
    ans = ''
    if request.method == 'POST':
        numb = request.POST.get('numb')
        ans = eratosthenes(int(numb))
    return render(request, 'main/chapter3/question02.html', {'ans': ans})


def chapter3q3(request):
    ans = ''
    if request.method == 'POST':
        numb = request.POST.get('numb')
        ans = eratosthenes(int(numb))
    return render(request, 'main/chapter3/question03.html', {'ans': ans})


def chapter3q4(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        ans = reverse((st))
    return render(request, 'main/chapter3/question04.html', {'ans': ans})


def chapter3q5(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        ans = lis((st))
    return render(request, 'main/chapter3/question05.html', {'ans': ans})


def chapter3q6(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        ans = binary(int(st))
    return render(request, 'main/chapter3/question06.html', {'ans': ans})

obj = DoublyLinkedList()
obj2 = DoublyLinkedList2()

def reconstruct():
    global obj, obj2
    obj = DoublyLinkedList()
    obj2 = DoublyLinkedList2()


def chapter4q1(request):
    global obj
    ans = obj.print
    if 'push' in request.POST:
        p = request.POST.get('st')
        obj.push(p)
        ans = obj.print
    elif 'pop' in request.POST:
        obj.remove()
        ans = obj.print
    elif 'reset' in request.POST:
        reconstruct()
        ans = obj.print
    return render(request, 'main/chapter4/question01.html', {'ans': ans})


def chapter4q2(request):
    global obj2
    ans = obj2.print()
    if 'push' in request.POST:
        p = request.POST.get('st')
        obj2.push(p)
        print('p:', p)
        ans = obj2.print()
    elif 'pop' in request.POST:
        obj2.pop()
        ans = obj2.print()
    elif 'reset' in request.POST:
        reconstruct()
        ans = obj2.print()
    print(ans)
    return render(request, 'main/chapter4/question02.html', {'ans': ans})


def chapter4q3(request):
    ans = ''

    return render(request, 'main/chapter4/question03.html', {'ans': ans})

def chapter5q1(request):
    a1, a2 = 0, 0
    st = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        st = list(map(int, st.strip().split()))
        st2 = request.POST.get('optradio')
        st2 = int(st2)
        if st2 == 6:
            quick_sort(st)
            a1, a2 = quick()
        if st2 == 5:
            a1 = merge_sort(st)
            x, a2 = mergeSortInversions(st)
        if st2 == 4:
            a1 = merge_sort(st)
            x, a2 = mergeSortInversions(st)
        if st2 == 3:
            a1, a2 = insertion_sort(st)
        if st2 == 2:
            a1, a2 = bubble_sort(st)
        if st2 == 1:
            a1, a2 = selection_sort(st)
        st = '  - '.join(str(x) for x in st)
    return render(request, 'main/chapter5/question01.html', {'a1': a1, 'a2': a2, 'st': st})
visited = []
p2 = ''
def chapter6q1(request):
    global visited, p2
    ans = ''
    x = ''
    y = ''
    if 'sub' in request.POST:
        p = request.POST.get('st')
        p2 = request.POST.get('st2')
        ans = range(int(p))
    if 'sup' in request.POST:
        graph = {}
        for i, j in request.POST.items():
            if i[0] == '-':
                graph[j] = request.POST[i[1]]
        for i, j in graph.items():
            graph[i] = graph[i].split(' ')
        dfs(visited, graph, p2)
        x = dfs_print()
        y = dfs_iterative(graph, p2)
        y = ' '.join(y)


    return render(request, 'main/chapter6/question01.html', {'ans': ans, 'x': x, 'y': y})

def chapter6q2(request):
    ans = ''

    return render(request, 'main/chapter6/question01.html', {'ans': ans})
q3 = ''
q32 = ''
visit = []
def chapter6q3(request):
    global q32, visit, q3
    ans = ''
    cycle = ''
    vv = True
    ab = False
    if 'sub' in request.POST:
        q32 = request.POST.get('st')
        q3 = request.POST.get('st2')
        ans = range(int(q32))
    if 'sup' in request.POST:
        ab = True
        graph = {}
        for i, j in request.POST.items():
            if i[0] == '-':
                graph[j] = request.POST[i[1]]
        for i, j in graph.items():
            graph[i] = graph[i].split(' ')
        print(graph)
        dfs2(visit, graph, q3)
        cycle = dff()
        if cycle:
            cycle = False
        else:
            cycle = True
        if q32 == len(visit):
            vv = False
    return render(request, 'main/chapter6/question03.html', {'ans': ans, 'cycle': cycle, 'vv': vv, 'ab': ab})

def chapter6q4(request):
    ans = ''

    return render(request, 'main/chapter6/question01.html', {'ans': ans})

q, qq, mat = 0, 0, ''
def chapter6q5(request):
    ans = []
    global q, qq, mat
    if 'sub' in request.POST:
        ans = True
        q = int(request.POST.get('st'))
        qq = int(request.POST.get('st2'))
        mat = np.zeros((q, q), dtype=int)
    if 'sup' in request.POST:
        q3 = int(request.POST.get('st3'))
        q4 = int(request.POST.get('st4'))
        q5 = int(request.POST.get('st5'))
        lp = []
        for i in range(qq):
            lp.append([request.POST[str(i)], request.POST['-{}'.format(i)]])
        for i in lp:
            i = map(int, i)
        for i in lp:
            mat[int(i[0]) - 1][int(i[1]) - 1] = 1
            mat[int(i[1]) - 1][int(i[0]) - 1] = 1
            pass
        cnt = 0
        for i in mat[q3]:
            if i == 1:
                cnt += 1
        ans.append(cnt)
        tmp = []
        for i in range(len(mat[q4])):
            if mat[q4][i] == 1:
                tmp.append(i + 1)
        ans.append(tmp)

        result = mat
        for _ in range(q5):
            result = np.dot(mat, result)
        print(result)
        tmpp = []
        for i in range(q):
            for j in range(q):
                if i > j:
                    tmpp.append('There are {} path with the inputed length between node {} and {}'.format(result[i][j], j + 1,
                                                                                                                        i + 1))
        ans.append(tmpp)
        print(ans)
    return render(request, 'main/chapter6/question05.html', {'ans': ans, 'qq': range(qq)})

def chapter6q6(request):
    m1 = ''
    len2 = ''
    ans = ''
    if request.method == 'POST':
        m1 = request.POST.get('st')
        m1 = m1.split('\r\n')
        len2 = len(m1)
        tmp = []
        for i in m1:
            tmp.append(list(map(int, i.split())))
        m1 = tmp
        ans = dee(len2, m1)
    return render(request, 'main/chapter6/question06.html', {'m1': m1, 'ans': ans})


def dee(x, y):
    g = Graph(x)
    g.graph = y
    return "Yes" if g.isBipartite(0) else "No"

def chapter7q1(request):
    ans = ''

    return render(request, 'main/chapter7/question01.html', {'ans': ans})
bstree = BSTree()

def chapter7q2(request):
    q = ''
    ans = ''
    global bstree
    if 'sub' in request.POST:
        q = True
        q = int(request.POST.get('st'))
        bstree.add(q)
        ans = bstree.prr()
    elif 'sub1' in request.POST:
        q = True
        q = int(request.POST.get('st'))
        bstree.remove(q)
        ans = bstree.prr()
    elif 'sub2' in request.POST:
        q = True
        q = int(request.POST.get('st'))
        ans = bstree.search(q)
    elif 'sub4' in request.POST:
        recns()
    print('ans', ans)
    return render(request, 'main/chapter7/question02.html', {'ans': ans, 'q': q})


def recns():
    global bstree
    bstree = BSTree()


def chapter7q6(request):
    ans = ''
    if request.method == 'POST':
        st = request.POST.get('st')
        x = hff(st)
        ans = [i.replace(' ', '---') for i in x]

    return render(request, 'main/chapter7/question06.html', {'ans': ans})


def chapter7q24(request):
    ans = ''

    return render(request, 'main/chapter7/question02.html', {'ans': ans})