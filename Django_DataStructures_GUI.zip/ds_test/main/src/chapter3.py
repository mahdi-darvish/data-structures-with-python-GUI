class Queue(object):  # Creating Queue class
    def __init__(self, type_of_queue, type_of_elements, length):  # Getting data from user
        self.type_of_queue = type_of_queue  # Declaring variables inside class for further uses
        self.type_of_elements = type_of_elements
        self.length = length
        self.items = []
        self.counter = 0  # A counter to calculate if the linear Queue is full

    def push(self, item):  # Defining add to Queue method
        if self.type_of_queue == 'linear' and self.counter == self.length:  # check if linear Queue is full
            return "Queue is full"
        if len(self.items) == self.length:  # check if cyclic Queue is full
            return "Queue is full"
        else:
            if type(item) == self.type_of_elements:  # validate type of inputted item
                if self.type_of_queue == 'linear':  # Special count for linear Queue
                    self.counter += 1
                self.items.insert(0, item)  # Add the item to Queue
                return item
            else:
                return "wrong data type"
    def pop(self):  # Defining Remove from Queue method
        if self.items == []:  # check if the Queue is empty or not
            return "Queue is empty"
        else:
            return self.items.pop()  # Remove item from Queue

    def is_full(self):  # Check if Queue is full or not and returns a boolean value
        return len(self.items) == self.length

    def is_empty(self):  # Check if Queue is empty or not and returns a boolean value
        return self.items == []

    def print(self):  # Show Queue Content
        for i in range(len(self.items)):
            print(self.items[i], end=' ')
        print()



class Stack(object): # Creating Stack class
    def __init__(self, type_of_elements, length): # Getting data from user
        self.type_of_elements = type_of_elements # Declaring needed variables
        self.length = length
        self.items = []

    def push(self, item): # Defining add to Stack function
        if self.is_full(): # check if its full
            return "stack is full"
        else:
            if type(item) == self.type_of_elements: # check if correct data type inserted
                self.items.append(item) # Adding the inputted item to the Stack
                return item
            else:
                return "wrong data type"

    def is_empty(self):
        return self.items == []

    def pop(self): # Define remove from Stack function
        if self.items == []: # check if it's empty or not
            return "stack is empty"
        else:
            return self.items.pop() # Removing the inputted item from Stack

    def is_full(self): # check if Stack is full and return Boolean variable
        return len(self.items) == self.length

    def print(self): # Show the Stack content in a user friendly manner
        for i in range(len(self.items)):
            print(self.items[i], end=' ')

def reverse(inp_str):
    s = Stack(str, len(inp_str)) # Creating a Stack Object
    for i in inp_str: # Push All the Elements into Stack
        s.push(i)
    ans = ''
    for i in range(len(inp_str)): # Pop all the Pushed elements from stack and show them to user
        ans +=s.pop()
    return ans

def binary(target):
    s = Stack(int, 100)  # Creating a Stack Object
    ans = ''

    for i in range(1, target): # loop through 1 to the inputted number\
        tmp =''
        while i > 0:  # loops Until i equals to 0
            s.push(i % 2) # push reminder of i to 2 into stack
            i //= 2  # Divide i by 2
        while not s.is_empty():  # Pop All the Pushed integers from Stack and show it to user
            tmp += "{}".format(s.pop())
        ans += tmp + "     "
    return ans

def lis(inp):
    x = list(map(int, inp.strip().split(',')))  # Collecting a list of integers from user and format it.
    q = Queue('cyclic', int, len(x))  # Creating an object from Queue

    temp = q.push(x[0]) # Save First element that is pushed into Queue into a temporary variable
    for i in range(len(x)):  # loop through numbers
        try:
            if x[i] >= temp:  # if next number is bigger than the last pushed item
               temp = q.push(x[i]) # tries to push it into Queue
        except: # exception handler
            pass
    q.pop() # remove the first number because it was pushed twice
    ans =''
    while not q.is_empty():
        ans += str(q.pop()) + ' ' # Remove every single element from Queue and show it to user
    return ans