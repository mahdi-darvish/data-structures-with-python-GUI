def eratosthenes(x):
    result_list = list(range(2, 1001)) # Creating a list from 2 to 1000
    count = 0 # Setting counter to 0
    while result_list != []:
        temp = result_list[0] # Storing first element of the list in a temp variable
        result_list.pop(0) # removing the first element and increasing the counter
        count += 1
        if x == temp: # Check if the removed value is the one that is asked for and returning the counter
            return count
        for item in result_list: # Removing all the multiples of the removed items and increase counter for each one
            if item % temp == 0:
                result_list.remove(item)
                count += 1
                if x == item: # Same as last if statement
                    return count


def char_replacement(target):
    result = ""  # Creating an empty string to collect result
    for item in target:  # loop through target
        temp = ord(item)  # Converting each char to ASCII value
        if 91 > temp > 64:  # Check if it's lowercase
            temp += 32
        elif 123 > temp > 96:  # Check if it's uppercase
            temp -= 32
        elif temp == 32:  # Check if its space and Convert it
            temp = 95
        result += chr(temp)  # Adding each char to result string

    return result  # Showing the result


def repeated_ints(inp_str):
    inp_str += ' '  # Getting input from user and concatenate it with a space
    ints_list = []  # Declare an empty list to store the integers
    temp = ''
    for item in inp_str:  # Loop through each character in the inputted string
        if item == ' ':  # When reach the space set a flag to True
            flag = True
            for item in temp:
                if 47 < ord(item) <= 58 or item == '-':
                    pass  # Flag remains True until hit a non-numeric char
                else:
                    flag = False
            if flag:  # If all of the temp chars were integers append them all to the list of ints
                ints_list.append(temp)
            temp = ''  # Clears temp for future usage
        else:
            temp += item  # Goes forward and adds each item to temp until hits space
    dic = {}  # Declare a dictionary to save key value pairs(numbers and their counts)
    for item in ints_list:
        if item in dic:  # If the item already exists in dic, increase the count by one
            dic[item] += 1
        else:  # Otherwise make a element with count 1
            dic[item] = 1
    return dic


def b_search(inp_arr, target):
    inp_arr = list(map(int, inp_arr.split()))
    target = int(target)
    # Declares lower and upper boundaries
    lower_bound = 0
    upper_bound = len(inp_arr) - 1
    while upper_bound > lower_bound: # loops until lower goes more than upper
        middle = upper_bound + lower_bound // 2 # storing the middle of array
        # Checks the state of target compared to middle of the array returns the value change array boundaries
        if target == inp_arr[middle]:
            return middle
        elif target > inp_arr[middle]:
            lower_bound = middle + 1
        elif target < inp_arr[middle]:
            upper_bound = middle - 1
    return -1


def matrix(m1, m2):
    first_matrix = []
    second_matrix = []
    result_matrix = []
    m1 = m1.split('\r\n')
    m2 = m2.split('\r\n')
    tmp = []
    tmp2 = []
    for i in m1:
        tmp.append(list(map(int, i.split())))
    for i in m2:
        tmp2.append(list(map(int, i.split())))
    m1 = tmp
    m2 = tmp2
    first_matrix_rows, first_matrix_columns, second_matrix_rows, second_matrix_columns =\
        len(m1),len(m1[0]), len(m2), len(m2[0])  # Getting the data
    first_matrix = m1
    second_matrix = m2
    if first_matrix_columns != second_matrix_rows:
        return 'These matrices are not multiplicable !'
    # Filling the result matrix with zeros
    for i in range(first_matrix_rows):
        temp = []
        for j in range(second_matrix_columns):
            temp.append(0)
        result_matrix.append(temp)
    # Calculating each element of the result array with nested loops
    for i in range(first_matrix_rows):
        for j in range(second_matrix_columns):
            temp = 0  # declaring a temporary variable to store sum of each multiplication
            for k in range(first_matrix_columns):
                temp += first_matrix[i][k] * second_matrix[k][j]  # (n-th row of first matrix multiply by column if second one
            result_matrix[i][j] = temp
    # Showing the result matrix using nested fop loops
    return result_matrix

def lcs(inp_arr):
    inp_arr = (list(map(int, inp_arr.split())))  # Collecting array from user

    best, current = 0, 0
    for i in inp_arr:  # Loop through array
        current += i  # Adds every element to current variable
        if current < 0:  # If it gets negative that makes our best smaller so we can cut off and start from 0
            current = 0
        best = max(best, current)  # If current gets bigger than best we had so far, we'll change it to current value
    return best # Print the result

def pi_e(frequency):
    import numpy as np  # Importing numpy library to generate random data for arrays.
    import matplotlib.pyplot as plt  # Importing matplotlib to visualize the result.
    from cmath import pi  # Using cmath library to access the exact pi value.

    # Creating the data
    x = np.random.rand(frequency)  # Random generated data on the x and y axis.
    y = np.random.rand(frequency)

    x_inside = []  # Declaring 2 separated arrays.
    x_outside = []
    y_inside = []
    y_outside = []

    dots_inside, dots_outside = 0, 0  # Counters to calculate the dots outside and inside.

    for i in range(frequency):  # Using a for loop to iterate through the arrays.
        if x[i] ** 2 + y[
            i] ** 2 > 1:  # check if the distance between the dot and center coordinate is more than 1( outside the circle).
            dots_inside += 1
            x_outside.append(x[i])
            y_outside.append(y[i])
        else:
            x_inside.append(x[i])
            y_inside.append(y[i])
            dots_outside += 1

    # Using some simple math calculations to estimate pi value by comparing the circle value to the whole square.
    ls = []
    ls.append(float(dots_outside) / float(dots_outside + dots_inside) * 4)
    ls.append(round(pi, 4))

    # Plotting the centered circle quarter using Circle function.
    circle = plt.Circle((0, 0), 1, fill=False, hatch="\\\\\\")
    # Adding the circle to the plot.
    fig, ax = plt.subplots()
    ax.add_artist(circle)

    # Defining the area of each dot on the plot.
    area = np.pi * 0.3
    # Using scatter function to plot all the dots inside and outside the circle with different colors.
    plt.scatter(x_inside, y_inside, s=area, c='b', alpha=1)
    plt.scatter(x_outside, y_outside, s=area, c='y', alpha=1)
    # Showing the result
    plt.title('Scatter Plot Result :')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.savefig(r"C:\Users\LENOVO\PycharmProjects\ds_testt\ds_test\static\img\foo.png")
    return ls

