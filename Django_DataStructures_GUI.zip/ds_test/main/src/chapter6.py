import numpy as np
visited = []
s = ''
def dfs_print():
    global s
    return s
def dfs(visited, graph, node):
    global s
    if node not in visited:
        s += str(node)
        s += ' '
        visited.append(node)
        for neighbour in graph[node]:
            dfs(visited, graph, neighbour)





def bfs(visited, graph, node):
   queue = []  # Initialize a queue
   visited.append(node)
   queue.append(node)

   while queue:
       s = queue.pop(0)
       print (s, end = " ")

       for neighbour in graph[s]:
           if neighbour not in visited:
               visited.append(neighbour)
               queue.append(neighbour)
   print()


def dfs_iterative(graph, start):
    stack, path = [start], []

    while stack:
        vertex = stack.pop()
        if vertex in path:
            continue
        path.append(vertex)
        for neighbor in graph[vertex]:
            stack.append(neighbor)

    return path



vertex = 0
cycle = False
def dfs2(visited, graph, node):
    global cycle
    if node not in visited:
        # print(node, end=', ')
        visited.append(node)
        for neighbour in graph[node]:
            dfs(visited, graph, neighbour)
    else:
        cycle = True

def dff():
    global cycle
    return cycle


class Graph():

    def __init__(self, V):
        self.V = V
        self.graph = [[0 for column in range(V)] \
                      for row in range(V)]

    # This function returns true if graph G[V][V]
    # is Bipartite, else false
    def isBipartite(self, src):

        # Create a color array to store colors
        # assigned to all veritces. Vertex
        # number is used as index in this array.
        # The value '-1' of colorArr[i] is used to
        # indicate that no color is assigned to
        # vertex 'i'. The value 1 is used to indicate
        # first color is assigned and value 0
        # indicates second color is assigned.
        colorArr = [-1] * self.V

        # Assign first color to source
        colorArr[src] = 1

        # Create a queue (FIFO) of vertex numbers and
        # enqueue source vertex for BFS traversal
        queue = []
        queue.append(src)

        # Run while there are vertices in queue
        # (Similar to BFS)
        while queue:

            u = queue.pop()

            # Return false if there is a self-loop
            if self.graph[u][u] == 1:
                return False

            for v in range(self.V):

                # An edge from u to v exists and destination
                # v is not colored
                if self.graph[u][v] == 1 and colorArr[v] == -1:

                    # Assign alternate color to this
                    # adjacent v of u
                    colorArr[v] = 1 - colorArr[u]
                    queue.append(v)

                # An edge from u to v exists and destination
                # v is colored with same color as u
                elif self.graph[u][v] == 1 and colorArr[v] == colorArr[u]:
                    return False

        # If we reach here, then all adjacent
        # vertices can be colored with alternate
        # color
        return True

import heapq
from collections import defaultdict


def encode(frequency):
    heap = [[weight, [symbol, '']] for symbol, weight in frequency.items()]
    count = 0
    while len(heap) > 1:
        count += 1
        lo = heapq.heappop(heap)
        hi = heapq.heappop(heap)
        for pair in lo[1:]:
            pair[1] += '0'
        for pair in hi[1:]:
            pair[1] += '1'
        heapq.heappush(heap, [lo[0] + hi[0]] + lo[1:] + hi[1:])
    return sorted(heapq.heappop(heap)[1:], key=lambda p: (len(p[-1]), p))

def hff(data):
    res = []
    frequency = defaultdict(int)
    for symbol in data:
        frequency[symbol] += 1
    huff = encode(frequency)
    res.append("Symbol".ljust(10) + "Weight".ljust(10) + "Huffman Code")
    for p in huff:
        res.append(p[0].ljust(10) + str(frequency[p[0]]).ljust(10) + p[1])
    return res

pr = []

class BSTNode:
    def __init__(self, key):
        self.key = key
        self.left = None
        self.right = None
        self.parent = None

    def insert(self, node):
        if self.key > node.key:
            if self.left is None:
                self.left = node
                node.parent = self
            else:
                self.left.insert(node)
        elif self.key < node.key:
            if self.right is None:
                self.right = node
                node.parent = self
            else:
                self.right.insert(node)

    def inorder(self):
        global pr
        if self.left is not None:
            self.left.inorder()
        pr.append(self.key)
        if self.right is not None:
            self.right.inorder()

    def replace_node_of_parent(self, new_node):
        if self.parent is not None:
            if new_node is not None:
                new_node.parent = self.parent
            if self.parent.left == self:
                self.parent.left = new_node
            elif self.parent.right == self:
                self.parent.right = new_node
        else:
            self.key = new_node.key
            self.left = new_node.left
            self.right = new_node.right
            if new_node.left is not None:
                new_node.left.parent = self
            if new_node.right is not None:
                new_node.right.parent = self

    def find_min(self):
        current = self
        while current.left is not None:
            current = current.left
        return current

    def remove(self):
        if (self.left is not None and self.right is not None):
            successor = self.right.find_min()
            self.key = successor.key
            successor.remove()
        elif self.left is not None:
            self.replace_node_of_parent(self.left)
        elif self.right is not None:
            self.replace_node_of_parent(self.right)
        else:
            self.replace_node_of_parent(None)

    def search(self, key):
        if self.key > key:
            if self.left is not None:
                return self.left.search(key)
            else:
                return None
        elif self.key < key:
            if self.right is not None:
                return self.right.search(key)
            else:
                return None
        return self


class BSTree:
    def __init__(self):
        self.root = None

    def inorder(self):
        if self.root is not None:
            self.root.inorder()
    def prr(self):
        self.inorder()
        global pr
        x = pr
        pr = []
        return x

    def add(self, key):
        new_node = BSTNode(key)
        if self.root is None:
            self.root = new_node
        else:
            self.root.insert(new_node)

    def remove(self, key):
        to_remove = self.search(key)
        if (self.root == to_remove
                and self.root.left is None and self.root.right is None):
            self.root = None
        else:
            to_remove.remove()

    def search(self, key):
        if self.root is not None:
            return self.root.search(key)
