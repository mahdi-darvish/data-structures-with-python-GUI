class DListNode:  # a class for Doubly Linked List Class to use as a node.

    def __init__(self, data=None, prev=None, next=None):
        self.data = data
        self.prev = prev
        self.next = next


class DoublyLinkedList:  # A doubly linked list class

    def __init__(self):  # Building Constructor

        self.head = None
        self.tail = None

    def print(self): # Prints a representation of the Class

        res = []
        curr = self.head
        while curr:
            res.append(curr.data)
            curr = curr.next
        return res

    def is_empty(self):
        return self.head == None


    def push(self, data):  # Insert a new element at the beginning of the list.

        tmp = DListNode(data)

        if self.tail == None:
            self.head = self.tail = tmp
            return
        self.tail.next = tmp
        self.tail = tmp

    def remove(self): # Remove the object that its name matches the key in the list.

        if self.is_empty():
            return
        temp = self.head
        self.head = temp.next

        if (self.head == None):
            self.tail = None
        return str(temp.data)


class DListNode2:  # a class for Doubly Linked List Class to use as a node.

    def __init__(self, data=None, next=None):
        self.data = data
        self.next = next


class DoublyLinkedList2:  # A doubly linked list class

    def __init__(self):  # Building Constructor

        self.head = None

    def print(self):  # Prints a representation of the Class
        res = []
        curr = self.head
        while curr:
            res.append(curr.data)
            curr = curr.next
        return res

    def is_empty(self):  # Checks if the List is empty.
        return self.head == None

    def push(self, data):  # Push item to top of the Stack.
        if self.head is None:
            self.head = DListNode2(data)
        else:
            new_node = DListNode2(data)
            new_node.next = self.head
            self.head = new_node

    def pop(self):  # Removes item from top of the Stack.
        if self.head is None:
            return None
        else:
            popped = self.head.data
            self.head = self.head.next
            return popped

def selection_sort(arr):
    cnt = 0
    cnt1 = 0
    for i in range(len(arr)-1,0,-1):
        positionofmax = 0
        for j in range(1,i+1):
            if arr[j] > arr[positionofmax]:
                cnt += 1
                positionofmax = j
        arr[i], arr[positionofmax] = arr[positionofmax], arr[i]
        cnt1 += 1
    return cnt,cnt1

def bubble_sort(arr):
    cnt = 0
    cnt1 = 0
    for n in range(len(arr)-1, 0, -1):
        for k in range(n):
            if arr[k] > arr[k+1]:
                cnt += 1
                arr[k], arr[k+1] = arr[k+1], arr[k]
                cnt1 += 1
    return cnt, cnt1

def insertion_sort(arr):
    cnt = 0
    cnt1 = 0
    for i in range(1,len(arr)):
        current = arr[i]
        while i > 0 and arr[i-1] > current:
            cnt += 1
            arr[i] = arr[i-1]
            cnt1 += 1
            i -= 1
        arr[i] = current
    return cnt, cnt1

def merge_sort(arr):
    cnt = 0
    if len(arr) > 1:
        mid = len(arr) // 2
        lefthalf = arr[:mid]
        righthalf = arr[mid:]
        merge_sort(lefthalf)
        merge_sort(righthalf)
        i = 0
        j = 0
        k = 0
        while i < len(lefthalf) and j < len(righthalf):
            cnt += 2
            if lefthalf[i] < righthalf[j]:
                cnt += 1
                arr[k] = lefthalf[i]
                i += 1
            else:
                arr[k] = righthalf[j]
                j += 1
            k += 1
        while i < len(lefthalf):
            cnt += 1
            arr[k] = lefthalf[i]
            i += 1
            k += 1
        while j < len(righthalf):
            cnt += 1
            arr[k] = righthalf[j]
            j += 1
            k += 1
    return cnt

def mergeSortInversions(arr):
    if len(arr) == 1:
        return arr, 0
    else:
        a = arr[:len(arr)//2]
        b = arr[len(arr)//2:]
        a, ai = mergeSortInversions(a)
        b, bi = mergeSortInversions(b)
        c = []
        i = 0
        j = 0
        inversions = 0 + ai + bi
    while i < len(a) and j < len(b):
        if a[i] <= b[j]:
            c.append(a[i])
            i += 1
        else:
            c.append(b[j])
            j += 1
            inversions += (len(a)-i)
    c += a[i:]
    c += b[j:]
    return c, inversions


cnt, cnt1 = 0, 0
def quick_sort(arr):

    quick_sort_help(arr, 0, len(arr)-1)

def quick_sort_help(arr, first, last):
    global cnt
    if first < last:
        cnt += 1
        point = partition(arr, first, last)
        quick_sort_help(arr, first, point-1)
        quick_sort_help(arr, point+1, last)
def partition(arr, first, last):
    global cnt, cnt1
    pivot = arr[first]
    leftmark = first + 1
    rightmark = last
    done = False
    while not done:
        while leftmark <= rightmark and arr[leftmark] <= pivot:
            cnt += 2
            leftmark += 1
        while arr[rightmark] >= pivot and rightmark >= leftmark:
            cnt += 2
            rightmark -= 1
        if rightmark < leftmark:
            cnt += 1
            done = True
        else:
            arr[leftmark], arr[rightmark] = arr[rightmark], arr[leftmark]
            cnt1 += 1
    arr[first], arr[rightmark] = arr[rightmark], arr[first]
    cnt1 += 1
    return rightmark

def quick():
    global cnt, cnt1
    return cnt, cnt1

