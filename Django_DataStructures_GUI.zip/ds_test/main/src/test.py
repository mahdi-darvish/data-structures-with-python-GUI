def test(m1, m2):
    m1 = m1.split('\r\n')
    m2 = m2.split('\r\n')
    tmp = []
    tmp2 = []
    for i in m1:
        tmp.append(list(map(int, i.split())))
    for i in m2:
        tmp2.append(list(map(int, i.split())))
    m1 = tmp
    m2 = tmp2
    print(m2)
    print(m1)