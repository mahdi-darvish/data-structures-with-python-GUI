"""
    ........1
    ......1...1
    ....1...2...1
    ..1...3...3...1
    1...4...6...4...1

"""
x = 5
y =x+(x-1)*3

ans = []
for _ in range(x):
    tmp = []
    for _ in range(y):
        tmp.append(0)
    ans.append(tmp)

for i in range(x):
    for j in range(y):
        if 2*(x-i-1) == j or y - 2*(x-i)+1 == j:
            ans[i][j] = 1
        elif True:
            pass

for i in range(x):
    for j in range(y):
        print(ans[i][j], end='')
    print()
